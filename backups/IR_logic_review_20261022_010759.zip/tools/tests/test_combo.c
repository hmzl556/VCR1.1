#include "mock_app.h"
#include "combo_key.c"
void ir_send_pair_code_target(bool tv){assert(bond_clears==pair_calls+1u);assert(g_pairing_active);++pair_calls;last_pair_tv=tv;}
bool ir_user_switch_stb(void){++switch_calls;return false;}
bool ir_user_switch_tv(void){++switch_calls;return true;}
static void scan(unsigned t,unsigned mask){uint32_t hw[5]={mask,0,0,0,0};now_ms=t;combo_key_process(t,hw);}
int main(void){unsigned i;unsigned tv=(1u<<14)|(1u<<3),stb=(1u<<14)|(1u<<2),user=(1u<<12)|(1u<<10);
 combo_key_init();scan(0,tv);scan(3000,tv);assert(pair_calls==1&&last_pair_tv==1);
 for(i=3010;i<12000;i+=10)scan(i,tv);assert(pair_calls==1);scan(12010,0);assert(combo_key_is_idle());
 scan(12100,stb);scan(15100,stb);assert(pair_calls==2&&last_pair_tv==0);scan(15110,0);
 scan(16000,user);scan(19000,user);assert(switch_calls==1);for(i=19200;i<=22000;i+=200)scan(i,user);assert(switch_calls==1);scan(22010,0);
 scan(22100,(1u<<12)|(1u<<8));scan(25100,(1u<<12)|(1u<<8));assert(switch_calls==1);scan(25110,0);
 scan(26000,tv|(1u<<2));scan(30000,tv|(1u<<2));assert(pair_calls==2);scan(30010,0);
 ota_busy=1;scan(31000,tv);scan(34000,tv);ota_busy=0;scan(35000,tv);assert(pair_calls==2);scan(35010,0);scan(36000,tv);scan(39000,tv);assert(pair_calls==3);
 puts("combo: TV/STB IR target, one action per hold, user-switch latch, triple-key exclusion, OTA release latch PASS");return 0;}
