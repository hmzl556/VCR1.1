#include "mock_merge.h"
static const uint8_t *SystemGetMacAddr(void){static uint8_t m[6];return m;}
#include "remote_reports.c"
static unsigned period,updates,ota_tasks;static uint8_t read_data[RC_READ_LEN];
const uint8_t *ble_rc_svc_get_read(void){return read_data;}
uint8_t bat_get_level_percent(void){return 77;}
int cat1_iccid_get_raw(uint8_t out[20],uint8_t *len){memcpy(out,"898604F41525D1986801",20);*len=20;return 0;}
int cat1_time_get_bcd6_offset(uint8_t out[6],int8_t tz){(void)tz;memset(out,0x11,6);return 0;}
int cat1_time_sync_from_bcd6_fallback(const uint8_t b[6],int8_t tz){(void)b;(void)tz;return 0;}
void heartbeat_set_period_s(uint16_t p){period=p;++updates;}
void udp_ota_on_tag11_task(uint16_t sw,uint16_t n){(void)sw;(void)n;++ota_tasks;}
int rc_udp_aes_init(void){return 0;}
int rc_udp_aes_encrypt_data_field(const uint8_t *p,uint16_t n,uint8_t *o,uint16_t cap,uint16_t *len){assert(cap>=n);memcpy(o,p,n);*len=n;return 0;}
int rc_udp_aes_decrypt_data_field(const uint8_t *p,uint16_t n,uint8_t *o,uint16_t cap,uint16_t *len){assert(cap>=n);memcpy(o,p,n);*len=n;return 0;}
int main(void){uint8_t value[64],policy[6]={0},good[]={0,1,6,0,30},bad[]={6,0,1,0x7f},shortv[]={6,0};uint16_t n;
 memset(read_data,'0',sizeof(read_data));
 assert(!remote_build_tag01_value(value,&n)&&n==50&&value[27]==7&&!memcmp(value+28,"898604F41525D1986801",20)&&value[48]==8&&value[49]==77);
 assert(!remote_build_tag0A_value(value,&n)&&n==30&&value[0]==0&&value[7]==1&&!memcmp(value+8,"898604F41525D1986801",20)&&value[28]==2&&value[29]==77);
 assert(!remote_parse_tag11_payload(good,sizeof(good),policy)&&period==30&&updates==1&&!ota_tasks);
 assert(remote_parse_tag11_payload(bad,sizeof(bad),policy)<0&&period==30&&updates==1);
 assert(remote_parse_tag11_payload(shortv,sizeof(shortv),policy)<0&&updates==1);
 puts("reports: Tag01/Tag0A lengths, 20-byte ASCII ICCID, battery, Tag11 heartbeat-only acceptance, malformed update atomicity PASS");return 0;}
